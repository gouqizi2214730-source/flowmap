"""Gap-detect → backfill bridge (Task 4.3).

Wires a :class:`~crocodile.core.ingest.book_sync.BookSyncMachine` RESYNC to a
REST snapshot fetch, buffers live deltas during the resync window, and
applies them after the snapshot arrives (dropping any with seq below the
snapshot anchor — see :func:`~crocodile.core.ingest.book_sync.filter_buffered_book_deltas`).

Appendix §6:
  Gap ⇒ buffer live deltas, fire REST snapshot, apply REST then buffered
  deltas in order (handle in-flight race).  REST snapshot seeds the
  continuity chain.

Usage example (inside a connector's message loop)::

    bridge = BookResyncBridge(
        sync=OrderBookSync(venue="spot"),
        fetch_snapshot=my_rest_fetch,
        symbol="BTCUSDT",
    )
    sync.set_snapshot(last_update_id=rest_snapshot_id)

    async for raw in transport:
        delta = normalize_depth(raw, ...)
        # U comes from the wire depthUpdate (not stored on BookDelta).
        result = sync.feed(U=U, u=delta.seq_id, pu=delta.prev_seq_id)
        record = bridge.feed_sync_result(result, delta)
        if record is not None:
            await sink.put(record)

        if bridge.is_resyncing:
            # Inline-await complete_resync() in the message loop; no concurrent
            # background Task is needed for single-coroutine asyncio use.
            applied = await bridge.complete_resync()
            for r in applied:
                await sink.put(r)

Primary production wiring:

- ``BinanceConnector._handle_message`` (when ``book_delta`` /
  ``book_snapshot`` are subscribed) — see
  ``crocodile.crypto.exchanges.binance.connector``.
- ``OKXConnector._handle_message`` for the ``books`` channel — see
  ``crocodile.crypto.exchanges.okx.connector`` (``OkxOrderBookSync`` + REST
  ``GET /market/books``).

Bybit is deferred: REST ``u`` aligns only with ``orderbook.1000`` while the
connector streams ``orderbook.50``; Bybit recovery is re-snapshot /
re-subscribe, not this REST-anchored replay.  Shared helpers live in
``crocodile.core.ingest.book_sync`` for a future port.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Literal

from crocodile.core.ingest.book_sync import (
    BookSyncMachine,
    SyncResult,
    filter_buffered_book_deltas,
    keep_delta_after_snapshot,
)
from crocodile.core.schema.records import BookDelta, BookSnapshot

__all__ = [
    "BookRecord",
    "BookResyncBridge",
    "FetchSnapshotFn",
    "TradeGapResult",
    "TradeSeqGap",
]

log = logging.getLogger(__name__)

# Type alias: an async callable that fetches a REST book snapshot for a symbol.
FetchSnapshotFn = Callable[[str], Awaitable[BookSnapshot]]

# Records that the bridge can return / emit.
BookRecord = BookSnapshot | BookDelta


class BookResyncBridge:
    """Stateful bridge between a book sync machine and REST-snapshot resync.

    Responsibilities:
    - Translate ``SyncResult`` (APPLY/DROP/RESYNC) into emit-or-buffer decisions.
    - On RESYNC: enter resyncing mode, buffer subsequent deltas.
    - On ``complete_resync()``: fetch REST snapshot, update the sync state machine,
      apply buffered deltas with ``seq_id`` past ``snapshot.sequence_id``, return
      the ordered list of records to emit.
    - A second RESYNC while already resyncing clears the stale buffer and restarts.

    Thread-safety: not thread-safe; designed for single-coroutine asyncio use.
    """

    def __init__(
        self,
        sync: BookSyncMachine,
        fetch_snapshot: FetchSnapshotFn,
        symbol: str,
    ) -> None:
        self._sync = sync
        self._fetch_snapshot = fetch_snapshot
        self._symbol = symbol
        self._resyncing: bool = False
        # Buffer of deltas accumulated during a resync window.
        self._buffer: list[BookDelta] = []

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def is_resyncing(self) -> bool:
        """True while waiting for a REST snapshot to complete a resync."""
        return self._resyncing

    # ------------------------------------------------------------------
    # Public methods — hot path
    # ------------------------------------------------------------------

    def feed_sync_result(
        self,
        result: SyncResult,
        delta: BookDelta,
    ) -> BookDelta | None:
        """Process one sync result from OrderBookSync.feed().

        Parameters
        ----------
        result:
            The ``SyncResult`` returned by ``OrderBookSync.feed()`` for *delta*.
        delta:
            The ``BookDelta`` that was fed into the sync state machine.

        Returns
        -------
        ``delta`` if it should be emitted to the sink immediately, or
        ``None`` if it was dropped or buffered.

        Side-effects:
        - RESYNC: enters resyncing mode; *delta* is buffered (not emitted).
        - DROP / RESYNC while resyncing: delta is buffered; returns ``None``.
        - APPLY while not resyncing: returns *delta* for the caller to emit.
        """
        if result == SyncResult.RESYNC:
            if self._resyncing:
                # Second RESYNC while already resyncing: clear stale buffer,
                # buffer the new RESYNC-triggering delta.
                log.warning(
                    "BookResyncBridge [%s]: second RESYNC while already resyncing; "
                    "clearing stale buffer (had %d deltas).",
                    self._symbol,
                    len(self._buffer),
                )
                self._buffer = []
            else:
                log.warning(
                    "BookResyncBridge [%s]: RESYNC triggered at seq=%s; entering resync mode.",
                    self._symbol,
                    delta.seq_id,
                )
                self._resyncing = True
            # Buffer the triggering delta — it may be valid post-resync.
            self._buffer.append(delta)
            return None

        if self._resyncing:
            # While resyncing, buffer everything (even DROPs).  Note: these
            # deltas are emitted as-is after seq-filtering on complete_resync();
            # the sync machine is re-anchored to snap_seq but the kept deltas
            # bypass it.
            self._buffer.append(delta)
            return None

        if result == SyncResult.DROP:
            return None

        # APPLY and not resyncing → emit directly.
        return delta

    def buffer_delta(self, delta: BookDelta) -> None:
        """Manually buffer a delta (e.g. arrived while resync I/O is in flight).

        Callers that manage the resync as a background coroutine can push
        deltas that arrive *after* RESYNC was signalled but *before*
        ``complete_resync()`` has finished.
        """
        self._buffer.append(delta)

    # ------------------------------------------------------------------
    # Resync completion
    # ------------------------------------------------------------------

    async def complete_resync(self) -> list[BookRecord]:
        """Fetch a REST snapshot and apply buffered deltas.

        Must be called when ``is_resyncing`` is True to complete the resync
        cycle.  Fetches the REST snapshot, updates the internal OrderBookSync
        state machine, applies buffered deltas with ``seq_id >=
        snapshot.sequence_id`` (drops stale ones), then clears the buffer and
        exits resyncing mode.

        Returns
        -------
        An ordered list of records to emit: [BookSnapshot] + kept deltas.
        """
        snapshot = await self._fetch_snapshot(self._symbol)
        snap_seq = snapshot.sequence_id  # int | None

        log.info(
            "BookResyncBridge [%s]: REST snapshot fetched, sequence_id=%s; "
            "filtering %d buffered deltas.",
            self._symbol,
            snap_seq,
            len(self._buffer),
        )

        # Update the sync state machine with the new snapshot anchor.
        if snap_seq is not None:
            self._sync.set_snapshot(last_update_id=snap_seq)
        else:
            # snapshot.sequence_id is None: the REST snapshot carries no usable
            # anchor.  set_snapshot() is skipped, so the sync machine retains
            # its previous (pre-resync) snapshot_id.  All buffered deltas pass
            # the seq filter (snap_seq is None → keep everything), but
            # subsequent WS deltas will be evaluated against the stale anchor.
            # This is a best-effort recovery; callers should treat the output
            # with caution and consider triggering a second resync.
            log.warning(
                "BookResyncBridge [%s]: REST snapshot has sequence_id=None; "
                "sync state machine NOT re-anchored (stale anchor retained). "
                "All buffered deltas will be kept and continuity may be wrong.",
                self._symbol,
            )

        # Filter buffered deltas using the venue-aware threshold helper.
        #   Binance SPOT:    drop seq_id <= snap_seq (boundary already in snapshot)
        #   Binance FUTURES: drop seq_id <  snap_seq (boundary is the first valid event)
        venue = getattr(self._sync, "_venue", "spot")
        if snap_seq is not None:
            for delta in self._buffer:
                if delta.seq_id is not None and not keep_delta_after_snapshot(
                    delta, snap_seq, venue=venue
                ):
                    log.debug(
                        "BookResyncBridge [%s]: dropping buffered delta seq=%s "
                        "(snapshot %s, venue=%s).",
                        self._symbol,
                        delta.seq_id,
                        snap_seq,
                        venue,
                    )
        kept_deltas = filter_buffered_book_deltas(self._buffer, snap_seq, venue=venue)

        # Clear state
        self._buffer = []
        self._resyncing = False

        # Buffered deltas are emitted without re-running the sync machine feed().
        # Advance continuity so the next live event checks against the last
        # applied u (not first-event rules against the snapshot alone).
        if kept_deltas:
            last_seq = kept_deltas[-1].seq_id
            if last_seq is not None:
                self._sync.note_applied(last_seq)

        # Return snapshot first, then kept deltas (in buffered order).
        result: list[BookRecord] = [snapshot]
        result.extend(kept_deltas)
        return result


# ---------------------------------------------------------------------------
# Trade-sequence gap detector
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TradeGapResult:
    """Everything :class:`TradeSeqGap` knows about one sequence number.

    ``bool(result)`` is ``result.is_gap``, so this is a drop-in for the plain
    ``bool`` that :meth:`TradeSeqGap.feed` returns at ``if gap.feed(seq):``
    call sites.  The extra fields are what a REST backfill needs: the range
    ``expected .. got`` is exactly the run of trades that went missing.

    ``kind`` is ``"forward"`` for a skip, ``"backward"`` when the venue's
    sequence went *down* (a reconnect or a venue-side counter reset rather than
    lost data), and ``None`` when there was no gap.
    """

    is_gap: bool
    expected: int | None = None
    got: int | None = None
    skipped: int | None = None
    kind: Literal["forward", "backward"] | None = None

    def __bool__(self) -> bool:
        return self.is_gap


class TradeSeqGap:
    """Detect gaps in a monotonic trade sequence (e.g. Deribit ``trade_seq``).

    Deribit ``trade_seq`` is monotonically increasing per instrument and may
    skip (appendix §3.1: "may skip").  A skip signals missed trades and
    should trigger a REST backfill for the missing range.

    Usage::

        gap = TradeSeqGap()
        for trade in stream:
            if gap.feed(trade.seq):
                # gap detected — trigger backfill
                await backfill(...)

    :meth:`feed` answers only *whether* a gap happened.  Callers that need the
    missing range in order to backfill it call :meth:`feed_result` instead and
    read :class:`TradeGapResult`.
    """

    def __init__(self) -> None:
        self._last_seq: int | None = None

    def feed(self, trade_seq: int) -> bool:
        """Process one trade sequence number.

        Parameters
        ----------
        trade_seq:
            The ``trade_seq`` field from the incoming trade message.

        Returns
        -------
        ``True`` if a gap was detected (previous seq is not None and
        ``trade_seq != last_seq + 1``), ``False`` otherwise.  Use
        :meth:`feed_result` when the missing range matters.
        """
        return self.feed_result(trade_seq).is_gap

    def feed_result(self, trade_seq: int) -> TradeGapResult:
        """Process one trade sequence number and describe what happened.

        Same state machine as :meth:`feed` — this is where it actually lives —
        but the answer carries ``expected``/``got``/``skipped`` so the caller
        can backfill the missing range rather than only know that one exists.

        Note the backward branch: a sequence that goes *down* advances the
        baseline to the new (lower) value, so the stream is treated as having
        restarted there and the next sequential id is clean.  The equity fork
        deliberately did the opposite — it kept the old, higher baseline, which
        makes every subsequent trade after a venue counter reset report a gap.
        """
        if self._last_seq is None:
            # First trade: establish baseline, no gap.
            self._last_seq = trade_seq
            return TradeGapResult(is_gap=False, got=trade_seq)

        expected = self._last_seq + 1
        if trade_seq == expected:
            self._last_seq = trade_seq
            return TradeGapResult(is_gap=False, expected=expected, got=trade_seq)

        skipped = trade_seq - self._last_seq - 1
        kind: Literal["forward", "backward"] = "forward" if skipped >= 0 else "backward"
        if kind == "backward":
            # Backward / reset: sequence went backwards (e.g. exchange
            # restarted seq numbering after a reconnect).  Log clearly
            # instead of reporting a negative "skipped" count.
            log.warning(
                "TradeSeqGap: backward seq — expected seq=%d, got seq=%d "
                "(reset or reconnect without TradeSeqGap.reset() call?).",
                expected,
                trade_seq,
            )
        else:
            log.warning(
                "TradeSeqGap: gap detected — expected seq=%d, got seq=%d (skipped %d).",
                expected,
                trade_seq,
                skipped,
            )
        self._last_seq = trade_seq
        return TradeGapResult(
            is_gap=True,
            expected=expected,
            got=trade_seq,
            skipped=skipped,
            kind=kind,
        )

    def reset(self) -> None:
        """Reset the gap detector (e.g. after a reconnect)."""
        self._last_seq = None
